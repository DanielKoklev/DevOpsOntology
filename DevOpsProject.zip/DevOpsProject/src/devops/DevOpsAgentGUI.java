package devops;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class DevOpsAgentGUI extends JFrame {

	DevOpsAgent agent;
	
	List<Practice> services;
	JTextArea area;
	
	public DevOpsAgentGUI(DevOpsAgent agent, List<Practice> list) {
		this.agent = agent;
		services = list;
		init();
		
		addItemsForSell();
	}
	
	private void addItemsForSell() {
		StringBuilder sb = new StringBuilder();
		for(Practice currentPractice : services) {
			sb.append(currentPractice + "\n");
		}
		
		area.setText(sb.toString());
	}

	private void init() {
		
		area = new JTextArea(15,15);
		area.setAutoscrolls(true);
		
		JScrollPane scroll = new JScrollPane (area, 
				   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
				   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		
		
		
		JTextField practiceTypeTextField = new JTextField(15);
		JButton addPracticeButton = new JButton("Add Practice");
		JTextField practiceNameTextField = new JTextField(15);
		JTextField practiceToolsTextField = new JTextField(15);
		JButton addToolButton = new JButton("Add Tool");
		JButton removeToolButton = new JButton("Remove Tool From Practice");
		
		JTextField oldNameTool = new JTextField(15);
		JTextField newNameTool = new JTextField(15);
		JButton editToolButton = new JButton("Edit Tool");
		
		JTextField deleteToolNameTextField = new JTextField(15);
		JButton deleteToolButton = new JButton("Delete existing tool");
		
		JPanel panel = new JPanel(new GridLayout(5,1));
		
		JPanel row0 = new JPanel();
		
		
		row0.add(scroll);
		panel.add(row0);
		
		JPanel row1 = new JPanel();		
		row1.add(practiceTypeTextField);
		row1.add(addPracticeButton);
		panel.add(row1);
		
		JPanel row2 = new JPanel();
		
		row2.add(practiceNameTextField);
		row2.add(practiceToolsTextField);
		row2.add(addToolButton);
		row2.add(removeToolButton);
		panel.add(row2);
		
		JPanel row3 = new JPanel();
		row3.add(oldNameTool);
		row3.add(newNameTool);
		row3.add(editToolButton);
		panel.add(row3);
		
		JPanel row4 = new JPanel();
		row4.add(deleteToolNameTextField);
		row4.add(deleteToolButton);
		panel.add(row4);
		
				
		addPracticeButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String practiceName = practiceTypeTextField.getText();
				
				if(practiceName.length() > 0) {
					agent.createNewPracticeType(practiceName);
				}
				
			}
		});
		
		addToolButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String practiceName = practiceNameTextField.getText();
				String toolName = practiceToolsTextField.getText();
				
				if(practiceName.length() > 0 && toolName.length() > 0) {
					agent.addToolToPractice(practiceName, toolName);

					practiceNameTextField.setText("");
					practiceToolsTextField.setText("");
				}
			}
		});
		
		removeToolButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String practiceName = practiceNameTextField.getText();
				String toolName = practiceToolsTextField.getText();
				
				if(practiceName.length() > 0 && toolName.length() > 0) {
					agent.removeToolFromPractice(practiceName, toolName);
					
					practiceNameTextField.setText("");
					practiceToolsTextField.setText("");
				}				
			}
		});
		
		editToolButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String oldName = oldNameTool.getText();
				String newName = newNameTool.getText();
				
				if(oldName.length() > 0 && newName.length() >0 ) {
					agent.changeToolName(oldName, newName);
					oldNameTool.setText("");
					newNameTool.setText("");
				}
			}
		});
		
		
		deleteToolButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String name = deleteToolNameTextField.getText();
				if(name.length() > 0) {
					agent.deleteTool(name);
					
					deleteToolNameTextField.setText("");
				}
			}
		});
		
		add(panel);		
	
		setSize(800,400);
		
		setVisible(true);
	}
}
