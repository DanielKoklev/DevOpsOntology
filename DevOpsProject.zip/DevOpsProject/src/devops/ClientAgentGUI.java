package devops;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class ClientAgentGUI extends JFrame{
	
	ClientAgent agent;
	JTextField toolTF;
	JButton searchB;
	
	
	public ClientAgentGUI(ClientAgent agent) {
		this.agent = agent;
		init();
	}
	
	
	private void init() {
		toolTF = new JTextField();
		searchB = new JButton("I want to learn this!");
		searchB.addActionListener(clickListener);
		
		Box content = Box.createHorizontalBox();
		content.add(Box.createRigidArea(new Dimension(5,1)));
		content.add(toolTF);
		content.add(Box.createRigidArea(new Dimension(5,1)));
		content.add(searchB);
		content.add(Box.createRigidArea(new Dimension(5,1)));
		
		add(content);
		
		setVisible(true);
		setSize(300, 200);
	}
	
	private ActionListener clickListener = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			String toolName = toolTF.getText();
			
			if(toolName.length() > 0) {
				agent.setSearchedTool(toolName);
				
				toolTF.setText("");
			}
			
		}
	};

}
